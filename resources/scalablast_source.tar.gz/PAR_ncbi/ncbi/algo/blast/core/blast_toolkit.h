#ifndef _BLAST_TOOLKIT__H_
#define _BLAST_TOOLKIT__H_

/** @file blast_toolkit.h
 * Include C toolkit versions of basic definitions
 */
#include <ncbistd.h>

#endif
